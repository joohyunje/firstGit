package operator;

public class Oper1 {
	public static void main(String[] args) {
		
		// 관계(비교) 연산자
		boolean temp = 10 == 11;
		
		System.out.println(temp);
		System.out.println(10 == 11);
		
		// 논리 연산자
		// 여러 개의 조건을 연결해서 하나의 조건을 만든다.
		System.out.println(!(10 > 11) && 10 == 10);
		
		
	}
}











