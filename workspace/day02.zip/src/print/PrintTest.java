package print;

public class PrintTest {
	public static void main(String[] args) {
		
		// 주석 : 사람이 사람에게 설명하기 위해 작성하는 메모
		// ctrl + /
		// 주석의 또하나의 용도
		// 잠시 코드를 실행에서 제외할 때 사용한다.
		
		// <- 한 줄 주석
		/*범위 주석
		 * 
		 * 범위
		 * 주석 
		 * 
		 * */
		
		// 처음 작성해본 출력 메소드
		// println 이기 때문에 소괄호 안의 값을 출력 후 마지막에 줄바꿈 해준다.
		System.out.println("오늘은 day02일차");
		
		System.out.println(10+5);
//		System.out.println(10/0);
		System.out.println(10+3);
	}
}
