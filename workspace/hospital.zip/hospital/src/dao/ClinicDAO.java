package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ClinicDAO {
	
	private Connection con;
	private PreparedStatement pstm;
	private ResultSet rs;
	
	
	
}
