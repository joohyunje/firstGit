package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AnimalDAO {
	
	private Connection con;
	private PreparedStatement pstm;
	private ResultSet rs;
	
}
