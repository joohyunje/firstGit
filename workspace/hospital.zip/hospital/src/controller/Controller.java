package controller;

public class Controller {

	public Controller() {
		play();
	}
	
	private void play() {
		
	}
	
	
	
}
