package castingTask;

public class Drama extends OTT {
	void moveMarket() {
		System.out.println("굿즈 구매 사이트로 이동!");
	}
}
