package castingTask;

public class Animation extends OTT {
	void supportSub() {
		System.out.println("자막 지원");
	}
}
