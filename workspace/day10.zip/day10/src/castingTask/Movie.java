package castingTask;

public class Movie extends OTT {
	void support4D() {
		System.out.println("4D 로 영화가 시작합니다.");
	}
}
