package controller;

public class View {
	public static void main(String[] args) {
		
		new Controller();
		
	}
}
