package array;

public class ArrayHomework1 {
	public static void main(String[] args) {
//		5개의 정수를 입력받고 배열에 담은 후 최댓값과 최솟값을 출력
		
		
		
	}
}
