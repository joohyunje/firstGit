package dao;

import java.sql.Connection;

public class Test {
	public static void main(String[] args) {
		
		Connection connection = DBConnection.getConnection();
		
		
	}
}
