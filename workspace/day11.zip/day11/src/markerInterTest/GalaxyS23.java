package markerInterTest;

public class GalaxyS23 extends SamsungStuff implements MobileMarker {

}
