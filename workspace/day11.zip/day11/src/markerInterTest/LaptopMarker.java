package markerInterTest;

public interface LaptopMarker {

}
