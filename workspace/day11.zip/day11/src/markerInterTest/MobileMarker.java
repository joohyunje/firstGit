package markerInterTest;

public interface MobileMarker {

}
