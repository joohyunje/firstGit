package markerInterTest;

public class SamsungStuff {
	
}
