package ambiguityTest;

public interface InterA {
	
	default void printName() {
		System.out.println("InterA");
	}
	
}
